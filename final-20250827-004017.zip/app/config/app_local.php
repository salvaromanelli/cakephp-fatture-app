<?php
return [
    "debug" => true,  // Habilitar para ver errores
    "Security" => [
        "salt" => env("SECURITY_SALT", "DYhG93b0qyJfIxfs2guVoUubWwvniR2G0FgaC9mi")
    ],
    "Datasources" => [
        "default" => [
            "className" => "Cake\Database\Connection",
            "driver" => "Cake\Database\Driver\Mysql",
            "persistent" => false,
            "host" => "db",
            "username" => "cakephp_user",
            "password" => "cakephp_password",
            "database" => "cakephp_db",
            "encoding" => "utf8mb4",
            "timezone" => "UTC",
            "flags" => [],
            "cacheMetadata" => true,
            "log" => false,
            "quoteIdentifiers" => false,
            "url" => env("DATABASE_URL", null)
        ]
    ]
];
